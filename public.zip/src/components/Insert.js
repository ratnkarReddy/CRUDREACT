import React, { Component } from 'react';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export default class Insert extends Component {
 
    constructor(props){
        super(props);
        this.onChangeFirstName = this.onChangeFirstName.bind(this);
        this.onChangeLastName = this.onChangeLastName.bind(this);
        this.onChangeEmail = this.onChangeEmail.bind(this);
        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            first_name: '',
            last_name: '',
            email: '',
            nameerror:''

        }
                
    }
    valid(){
        if(!this.state.email.includes("@")){
            this.setState({nameerror:"invalid Email"})
        }else{
            return true;
        }
    }
     
      onChangeFirstName(e){
          this.setState({
             first_name: e.target.value
          });

      }
      onChangeLastName(e){
        this.setState({
           last_name: e.target.value
        });

    }
    onChangeEmail(e){
        this.setState({
           email: e.target.value
        });

    }
      onSubmit(e){
          e.preventDefault();
          this.setState({nameerror:""})
           
              
          if (this.valid()) {
              
           //alert("error")
           const obj ={
               first_name: this.state.first_name,
               last_name: this.state.last_name,
               email: this.state.email
           };
       

         axios.post('http://localhost/reactjscrud/insert.php', obj).then(res => console.log(res.data)).then(res => {
            toast.success("Successfully Inserted Data",{
                position:"top-left",
                autoClose:5000,
                hideProgressBar:false,
                closeOnClick:true,
                pauseOnHover:true,
                draggable:true,
                progress:undefined,
     
             }
             );
         } );
        
         //console.log(obj)

          toast.configure()
          
         this.setState({
             first_name:'',
             last_name:'',
             email:''
         })
        } 
      }
      
      
    render(){
        
        return(
            <div className="wrapper">
        <div className="form-wrapper">
            <div style={{marginTop: 10}}>
                <div>
                <h3>Add New User</h3>
                <form onSubmit={this.onSubmit}> 
                <div className="firstName">
                    <label htmlFor="name">UserName</label>
                    <input type="text" className="form-control" value={this.state.first_name} onChange={this.onChangeFirstName}/>
                  
                </div>
                <div className="firstName">
                    <label htmlFor="Lastname">Last Name</label>
                    <input type="text" className="form-control" value={this.state.last_name} onChange={this.onChangeLastName} />
                </div>
                <div className="firstName">
                    <label htmlFor="email">Email address:</label>
                    <input type="email" className="form-control" value={this.state.email} onChange={this.onChangeEmail}  />
                    <span style={{color:"red"}}>{this.state.nameerror}</span>
                </div>
                <div className="firstName">
                <input type="submit" className="btn btn-success"  /> <ToastContainer />
               </div> </form></div>
                
             </div></div></div>
        )
    }
}