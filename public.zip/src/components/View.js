import React, { Component } from 'react';
import axios from 'axios';
import Recordslist from './Recordslist';

export default class View extends Component {

     constructor(props){
         super(props);
         this.state = {students: []};

     }
     componentDidMount(){
         axios.get('http://localhost/reactjscrud/list.php').then(response => { 
             this.setState({students: response.data});

         })
         .catch(function(error){
             console.log(error);
         })
     }
     userslist(){
         return this.state.students.map(function(object, i){
             return <Recordslist obj={object} key={i} />
         });
     }

    render(){
        return(
            <div>
                <h3 align="center" style={{marginTop: 20}}>User List</h3>
                <table className="table table-striped" style={{marginTop: 20}}>
                    <thead>
                        <tr>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email ID</th>
                            <th colSpan="2">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.userslist()}
                    </tbody>
                </table>

            </div>
        );
    }
}