import React, { Component } from 'react';
import axios from 'axios';
import { Redirect } from 'react-router';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import {Link} from 'react-router-dom';

class Recordlist extends Component{
       
     constructor(props){
         super(props);
         this.delete = this.delete.bind(this); 
         this.state = {
             redirect: false
         }
     }
     delete(){
         axios.get('http://localhost/reactjscrud/delete.php?id='+this.props.obj.sid).then(res => {
            toast.error("Data Deleted Successfully",{
                position:"top-left",
                autoClose:5000,
                hideProgressBar:false,
                closeOnClick:true,
                pauseOnHover:true,
                draggable:true,
                progress:undefined,
     
             }
             );
         } )
         .then(
             this.setState({ redirect:true }) 

         )
         .catch(err => console.log(err))
     }

    render(){
         const { redirect } = this.state;
           if(redirect){
               return <Redirect to='/view' />;
           }
        return(
            <tr>
                <td>
                    {this.props.obj.fname}
                </td>
                <td>
                    {this.props.obj.lname}
                </td>
                <td>
                    {this.props.obj.email}
                </td>
                <td>
                <Link to={"/edit/"+this.props.obj.sid} className="btn btn-primary">EDIT</Link>

                </td>
                <td>
                    <button onClick={this.delete} className="btn btn-danger">DELETE</button>
                    
                </td>
            </tr>
        );
    }
}

export default Recordlist;