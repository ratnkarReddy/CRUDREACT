import React from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';

import './App.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import Insert from './components/Insert';
import Edit from './components/Edit';
import View from './components/View';




function App() {
  return (
   <Router>
     
    <div className="">
      <nav className="navbar navbar-expand-lg navbar-light bg-warning">
        <Link to={'/'} className="navbar-brand"><img src="http://localhost:3000/SBTS-Logo-1.png" alt="SBTS"/></Link>
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav mr-auto">
            <li className="nav-item">
              <Link to={'/'} className="nav-link">Home</Link>
            </li>
            <li className="nav-item">
              <Link to={'/Insert'} className="nav-link">Insert</Link>
            </li>
            <li className="nav-item">
              <Link to={'/view'} className="nav-link">View</Link>
            </li>
          </ul>
        </div>
      </nav>
      <Switch>
          <Route exact path='/insert' component={ Insert } />
          <Route exact path='/edit/:id' component={ Edit } />
          <Route exact path='/view' component={ View } />
      </Switch>
    </div>

   </Router>
  );
}

export default App;
